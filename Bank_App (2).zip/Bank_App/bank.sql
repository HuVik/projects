-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Okt 07. 22:19
-- Kiszolgáló verziója: 10.4.11-MariaDB
-- PHP verzió: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `bank`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `customers`
--

CREATE TABLE `customers` (
  `id` int(100) NOT NULL,
  `cust_id` varchar(9) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `accountType` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `accountNumber` int(100) NOT NULL,
  `address` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `phoneNumber` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `accountbalance` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `customers`
--

INSERT INTO `customers` (`id`, `cust_id`, `name`, `accountType`, `accountNumber`, `address`, `phoneNumber`, `email`, `accountbalance`) VALUES
(1, 'C001', 'Hüber Viktor', 'Folyó', 123456789, '1238.Bp.Szitás u. 71/b', '+36-70-326-57-85', 'vhuber@gmail.com', 1496317),
(7, 'C002', 'Folyékony Szilárd', 'Folyó', 8965321, '1238 Bp. Templom u.49', '+36-70-123-45-67', 'fsz@gmail.com', 2150002),
(8, 'C003', 'Pum Pál', 'Folyó', 564125987, '1222. Bp Lefolyó u. 58', '+36-70-522-36-63', 'pumpal@gmail.com', 3000000),
(9, 'C004', 'Kukor Ilona ', 'Folyó', 754869145, '1151. Bp. Színesfém u. 86.', '+36/70-412-75-84', 'kukorica@gmail.com', 6000000);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
