package controller;


import data.Database;

public class BankService {



    //deposit method
    public boolean deposit(String cust_id, int depositMoney){
        boolean success = false;
        Database dbForDeposit = new Database();
        success =  dbForDeposit.deposit(cust_id, depositMoney);
        return success;
    }

    //withdraw method
    public boolean withdraw(String cust_id, int depositMoney){
        boolean success = false;
        Database dbForWithdraw = new Database();
        success =  dbForWithdraw.withdraw(cust_id, depositMoney);
        return success;
    }
    //transfer method
    public boolean transfer(String custId, String anotherCustId,int transferAmount){
        boolean success = false;
        Database dbForTransfer = new Database();
        success = dbForTransfer.transfer(custId,anotherCustId,transferAmount);
        return success;
    }

}
