package graphics;

import data.Database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

@SuppressWarnings("serial")
public class OpenAccountMenu extends JFrame implements ActionListener {
    //class of open account menu

    //data types
    private JPanel accountPanel;

    private JLabel nameLabel;
    private JLabel cust_idLabel;
    private JLabel accountTypeLabel;
    private JLabel addressLabel;
    private JLabel phoneNumberLabel;
    private JLabel emailLabel;
    private JLabel accountNumberLabel;
    private JLabel accountBalanceLabel;
    private JLabel currency;

    private JTextField nameField;
    private JTextField cust_idField;
    private JTextField accountField;
    private JTextField addressField;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField accountNumberField;
    private JTextField accountBalanceField;

    private JButton ok;
    private JButton cancel;

    Database db;

    //constructor with init method
    public OpenAccountMenu(){

        init();

    }


    //init method for initialize components
    public void init(){

        //set frame
        this.setTitle("Számlanyitás");
        this.setSize(800,600);
        this.setLocationRelativeTo(null);

        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        //initialize cdatatypes and components
        this.accountPanel = new JPanel();
        this.accountPanel.setBackground(Color.gray);
        //this.setLayout(null);
        this.accountPanel.setLayout(null);
        //this.getContentPane().add(accountPanel);
        this.cust_idLabel = new JLabel("Ügyfél azonosító: ");
        this.nameLabel = new JLabel("Név: ");
        this.accountTypeLabel = new JLabel("Számla típus: ");
        this.addressLabel = new JLabel("Cím: ");
        this.phoneNumberLabel = new JLabel("Telefonszám: ");
        this.emailLabel = new JLabel("e-mail cím: ");
        this.accountNumberLabel = new JLabel("Számla szám: ");
        this.accountBalanceLabel = new JLabel("Számla egyenleg: ");
        this.currency = new JLabel("Ft");

        this.cust_idField = new JTextField();
        this.nameField = new JTextField();
        this.accountField = new JTextField();
        this.addressField = new JTextField();
        this.phoneField = new JTextField();
        this.emailField = new JTextField();
        this.accountNumberField = new JTextField();
        this.accountBalanceField = new JTextField();

        this.ok = new JButton("Mentés");
        this.cancel = new JButton("Mégse");

        //add components to panel
        this.accountPanel.add(cust_idLabel);
        this.accountPanel.add(cust_idField);

        this.accountPanel.add(nameLabel);
        this.accountPanel.add(nameField);

        this.accountPanel.add(accountTypeLabel);
        this.accountPanel.add(accountField);

        this.accountPanel.add(addressLabel);
        this.accountPanel.add(addressField);

        this.accountPanel.add(phoneNumberLabel);
        this.accountPanel.add(phoneField);

        this.accountPanel.add(emailLabel);
        this.accountPanel.add(emailField);

        this.accountPanel.add(accountNumberLabel);
        this.accountPanel.add(accountNumberField);

        this.accountPanel.add(accountBalanceLabel);
        this.accountPanel.add(accountBalanceField);

        this.accountPanel.add(currency);

        this.accountPanel.add(ok);
        this.accountPanel.add(cancel);

        //add actionlistener to buttons
        this.ok.addActionListener(this);
        this.cancel.addActionListener(this);

        //set positions and sizes of components
        this.cust_idLabel.setBounds(10,30,110,30);
        this.cust_idField.setBounds(130,30,150,30);

        this.nameLabel.setBounds(10,90,100,30);
        this.nameField.setBounds(130,90,150,30);

        this.accountTypeLabel.setBounds(10,150,100,30);
        this.accountField.setBounds(130,150,150,30);

        this.addressLabel.setBounds(10,210,100,30);
        this.addressField.setBounds(130,210,150,30);

        this.phoneNumberLabel.setBounds(10,270,100,30);
        this.phoneField.setBounds(130,270,150,30);

        this.emailLabel.setBounds(10,330,100,30);
        this.emailField.setBounds(130,330,150,30);

        this.ok.setBounds(10,400,100,50);
        this.cancel.setBounds(130,400,100,50);

        this.accountNumberLabel.setBounds(320,30,100,30);
        this.accountNumberField.setBounds(460,30,150,30);

        this.accountBalanceLabel.setBounds(320,90,120,30);
        this.accountBalanceField.setBounds(460,90,150,30);
        this.currency.setBounds(630,90,50,30);


        //add panel to the frame
        this.add(accountPanel);

        //set visibility
        this.setVisible(false);

    }


    @Override
    public void actionPerformed(ActionEvent actionEvent) {

        if (actionEvent.getSource().equals(this.ok)){
            checkFields();
            String id = this.cust_idField.getText();
            String name = this.nameField.getText();
            String accountType = this.accountField.getText();
            String accountNumber = this.accountNumberField.getText();
            String address = this.addressField.getText();
            String phoneNumber = this.phoneField.getText();
            String email = this.emailField.getText();
            int accountBalance = Integer.parseInt(this.accountBalanceField.getText());
            boolean success = this.db.reg(id,name,accountType,accountNumber, address,phoneNumber,email, accountBalance);
            ClearFields();

        }
        if (actionEvent.getSource().equals(this.cancel)){
            this.dispose();
        }

    }

    //method for clearing fields
    public void ClearFields(){
        this.cust_idField.setText("");
        this.nameField.setText("");
        this.accountField.setText("");
        this.accountNumberField.setText("");
        this.addressField.setText("");
        this.phoneField.setText("");
        this.emailField.setText("");
        this.accountBalanceField.setText("");

    }

    //setter to database connection
    public void setDb(Database connection) {
        this.db = connection;
    }

    //method to check fields
    public void checkFields(){

        if (this.cust_idField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Az azonosító kitöltése kötelező!");
        }

        if (this.nameField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"A név kitöltése kötelező!");
        }
        if (this.accountField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"A számla típus kitöltése kötelező!");
        }
        if (this.addressField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"A cím kitöltése kötelező!");
        }
        if (this.phoneField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"A telefonszám kitöltése kötelező!");
        }
        if (this.emailField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Az e-mail kitöltése kötelező!");
        }

    }

}
