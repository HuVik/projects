package graphics;

import data.Database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class View extends JFrame implements ActionListener {
    //class for main view of bank app
    //data types
    private JPanel panel;
    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenu serviceMenu;
    private JMenu transactionMenu;
    private JMenu reportMenu;
    private JMenuItem escMenuItem;
    private JMenuItem accountMenuItem;
    private JMenuItem depositMenuItem;
    private JMenuItem withdrawMenuItem;
    private JMenuItem transferMenuitem;
    private JMenuItem accountsReportMenuItem;


    private JLabel imageLabel;
    private ImageIcon image;

    private Database dataStream;
    private OpenAccountMenu OAM;
    private DepositMenu DP;
    private WithdrawMenu WM;
    private TransferMenu TM;
    private AccountsReport AR;

    //constructor with init method
    public View(){

        init();

    }

    //init method for initialize the components
    public void init() {

        //set frame
        this.setTitle("Bank Management System");
        this.setSize(800,800);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        //initialize components
        this.panel = new JPanel();
        this.menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);
        this.fileMenu = new JMenu("Fájl");
        this.escMenuItem = new JMenuItem("Kilépés");

        this.serviceMenu = new JMenu("Szolgáltatások");
        this.accountMenuItem = new JMenuItem("Számlanyitás");

        this.transactionMenu = new JMenu("Tranzakciók");
        this.depositMenuItem = new JMenuItem("Készpénzbefizetés");
        this.withdrawMenuItem = new JMenuItem("Készpénzfelvétel");
        this.transferMenuitem = new JMenuItem("Utalás");

        this.reportMenu = new JMenu("Riport");
        this.accountsReportMenuItem = new JMenuItem("Számlák lekérdezése");

        //initialize database class

        this.dataStream = new Database();
        this.OAM = new OpenAccountMenu();
        this.OAM.setDb(dataStream);

        //initialize menus
        this.DP = new DepositMenu();
        this.WM = new WithdrawMenu();
        this.TM = new TransferMenu();
        this.AR = new AccountsReport();

        //set panel
        this.panel.setSize(800,800);
        this.panel.setBackground(Color.darkGray);

        //set menus
        this.menuBar.setBackground(Color.lightGray);
        this.fileMenu.add(escMenuItem);
        this.serviceMenu.add(accountMenuItem);

        //set menu items
        this.transactionMenu.add(depositMenuItem);
        this.transactionMenu.add(withdrawMenuItem);
        this.transactionMenu.add(transferMenuitem);

        //add components to panel
        this.reportMenu.add(accountsReportMenuItem);

        //add menus to menu bar
        this.menuBar.add(fileMenu);
        this.menuBar.add(serviceMenu);
        this.menuBar.add(transactionMenu);
        this.menuBar.add(reportMenu);

        //add action listener to menu items
        this.escMenuItem.addActionListener(this);
        this.accountMenuItem.addActionListener(this);
        this.depositMenuItem.addActionListener(this);
        this.withdrawMenuItem.addActionListener(this);
        this.transferMenuitem.addActionListener(this);
        this.accountsReportMenuItem.addActionListener(this);

        //set picture in label
        this.imageLabel = new JLabel();
        this.image = new ImageIcon("pexels-pixabay-315788.jpg");
        imageLabel.setIcon(image);
        panel.add(imageLabel);

        //add panel to frame
        this.add(panel);

        //set visibility
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (actionEvent.getSource().equals(this.escMenuItem)){
            System.exit(0);
            this.dataStream.CloseDatabase();
        }
        if (actionEvent.getSource().equals(this.accountMenuItem)){
             this.OAM.ClearFields();
             this.OAM.setVisible(true);
        }
        if (actionEvent.getSource().equals(this.depositMenuItem)){
            DP.setVisible(true);
        }
        if (actionEvent.getSource().equals(this.withdrawMenuItem)){
            WM.setVisible(true);
        }
        if (actionEvent.getSource().equals(this.transferMenuitem)){
            TM.setVisible(true);
        }
        if (actionEvent.getSource().equals(this.accountsReportMenuItem)){
            AR.setVisible(true);
            this.AR.setDb(dataStream);

        }

    }
}
