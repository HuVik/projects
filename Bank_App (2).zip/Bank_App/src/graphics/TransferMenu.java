package graphics;

import controller.BankService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransferMenu extends JFrame implements ActionListener {
    //class for transfer menu

    //data types
    private JPanel transferPanel;
    private JLabel custId;
    private JLabel anotherCustId;
    private JTextField custIdField;
    private JTextField anotherCustIdField;
    private JLabel transferAmount;
    private JTextField transferAmountField;
    private JButton transferButton;
    private JButton cancelButton;
    private BankService BS;

    //constructor with init menu
    public TransferMenu(){

        init();

    }

    //init method to initialize datatypes and components
    private void init(){

        //initialize frame
        this.setTitle("Átutalás");
        this.setSize(800,600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.transferPanel = new JPanel();
        this.transferPanel.setLayout(null);
        this.transferPanel.setBackground(Color.gray);

        //initialize components
        this.custId = new JLabel("Ügyfél azonosító: ");
        this.custIdField = new JTextField();
        this.anotherCustId = new JLabel("Címzett ügyfél azonosító: ");
        this.anotherCustIdField = new JTextField();
        this.transferAmount = new JLabel("Utalni kívánt összeg: ");
        this.transferAmountField = new JTextField();
        this.transferButton = new JButton("Utalás");
        this.cancelButton = new JButton("Mégse");

        //setSize and set positions of the components
        this.custId.setBounds(10,50,150,30);
        this.custIdField.setBounds(190,50,100,30);
        this.anotherCustId.setBounds(10,110,150,30);
        this.anotherCustIdField.setBounds(190,110,100,30);
        this.transferAmount.setBounds(10,170,150,30);
        this.transferAmountField.setBounds(190,170,100,30);
        this.transferButton.setBounds(10,220,100,50);
        this.cancelButton.setBounds(190,220,100,50);

        //add actionlistener to buttons
        this.transferButton.addActionListener(this);
        this.cancelButton.addActionListener(this);

        //add components to panel
        this.transferPanel.add(custId);
        this.transferPanel.add(custIdField);
        this.transferPanel.add(anotherCustId);
        this.transferPanel.add(anotherCustIdField);
        this.transferPanel.add(transferAmount);
        this.transferPanel.add(transferAmountField);
        this.transferPanel.add(transferButton);
        this.transferPanel.add(cancelButton);

        //add transferPanel to frame
        this.add(transferPanel);
        //visibility of frame
        this.setVisible(false);
    }





    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(transferButton)){
            BS = new BankService();
            boolean succes = BS.transfer(custIdField.getText(),anotherCustIdField.getText(),Integer.parseInt(transferAmountField.getText()));
            if (succes){
              JOptionPane.showMessageDialog(null, "Sikeres átutalás!");
            }else {
              JOptionPane.showMessageDialog(null,"Sikertelen átutalás!");
            }
            ClearFields();
        }
        if (e.getSource().equals(cancelButton)){
            this.dispose();
        }

    }

    //method to clearing fields
    public void ClearFields(){
        this.custIdField.setText("");
        this.anotherCustIdField.setText("");
        this.transferAmountField.setText("");
    }
}
