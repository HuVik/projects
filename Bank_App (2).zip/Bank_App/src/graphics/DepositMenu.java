package graphics;

import controller.BankService;
import data.Database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DepositMenu extends JFrame implements ActionListener{

    //data types
    private JPanel depositPanel;
    private JLabel cust_idLabel;
    private JLabel moneyLabel;

    private JTextField cust_idField;
    private JTextField moneyField;

    private JButton approveButton;
    private JButton cancelButton;
    private BankService BS;

    private Database db;

    //constructor with init method
    public DepositMenu(){

        init();

    }

    //init method for initialize datatypes and components
    private void init(){

        this.setTitle("Készpénzbefizetés számlára");
        this.setSize(800,600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.depositPanel = new JPanel();
        this.depositPanel.setLayout(null);
        this.depositPanel.setBackground(Color.gray);

        this.cust_idLabel = new JLabel("Ügyfél azonosító: ");
        this.cust_idField = new JTextField();

        this.moneyLabel = new JLabel("Beviteli összeg: ");
        this.moneyField = new JTextField();

        this.approveButton = new JButton("Jóváhagyás");
        this.cancelButton = new JButton("Mégse");

        //set positions and sizes of components
        this.cust_idLabel.setBounds(10,150,150,30);
        this.cust_idField.setBounds(140,150,150,30);

        this.moneyLabel.setBounds(10,200,150,30);
        this.moneyField.setBounds(140,200,150,30);

        this.approveButton.setBounds(30,250,100,50);
        this.cancelButton.setBounds(190,250,100,50);

        this.approveButton.addActionListener(this);
        this.cancelButton.addActionListener(this);

        //add components to panel
        this.depositPanel.add(cust_idLabel);
        this.depositPanel.add(cust_idField);
        this.depositPanel.add(moneyLabel);
        this.depositPanel.add(moneyField);
        this.depositPanel.add(approveButton);
        this.depositPanel.add(cancelButton);
        this.add(depositPanel);
        //set visibility
        this.setVisible(false);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(approveButton)){
            BS = new BankService();
            boolean success = BS.deposit(cust_idField.getText(), Integer.parseInt(moneyField.getText()));
            if(success) {
                JOptionPane.showMessageDialog(null, "Sikeres befizetés!");
            }else {
                JOptionPane.showMessageDialog(null,"Sikertelen befizetés!");
            }
            ClearFields();
        }
        if (e.getSource().equals(cancelButton)){
            this.dispose();
        }
    }


    //method to clear fields
    public void ClearFields(){
        this.cust_idField.setText("");
        this.moneyField.setText("");

    }

}
