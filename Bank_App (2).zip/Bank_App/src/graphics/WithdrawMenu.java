package graphics;

import controller.BankService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WithdrawMenu extends JFrame implements ActionListener {
    //class for withdraw menu

    //data types
   private JPanel withdrawPanel;
   private JLabel custIDLabel;
   private JTextField custIDField;
   private JLabel moneyLabel;
   private JTextField moneyField;
   private JButton withdrawButton;
   private JButton cancelButton;
   private BankService BS;

   //constructor with init method
   public WithdrawMenu(){

       init();

   }

   //init method for  initialize data types and components
   private void init(){
       this.setTitle("Készpénzfelvétel számláról");
       this.setSize(800,600);
       this.setLocationRelativeTo(null);
       this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
       withdrawPanel = new JPanel();
       this.withdrawPanel.setLayout(null);
       this.withdrawPanel.setBackground(Color.gray);

       this.custIDLabel = new JLabel("Ügyfél azonosító: ");
       this.custIDField = new JTextField();

       this.moneyLabel = new JLabel("Felvételi összeg: ");
       this.moneyField = new JTextField();

       this.withdrawButton = new JButton("Készpénzfelvétel");
       this.cancelButton = new JButton("Mégse");

       //set positions and sizes of components
       this.custIDLabel.setBounds(10,150,150,30);
       this.custIDField.setBounds(140,150,150,30);

       this.moneyLabel.setBounds(10,200,150,30);
       this.moneyField.setBounds(140,200,150,30);

       this.withdrawButton.setBounds(30,250,150,50);
       this.cancelButton.setBounds(190,250,100,50);

       //add action listener to buttons
       this.withdrawButton.addActionListener(this);
       this.cancelButton.addActionListener(this);

       //add components to panel
       this.withdrawPanel.add(custIDLabel);
       this.withdrawPanel.add(custIDField);
       this.withdrawPanel.add(moneyLabel);
       this.withdrawPanel.add(moneyField);
       this.withdrawPanel.add(withdrawButton);
       this.withdrawPanel.add(cancelButton);

        //add panel to frame
       this.add(withdrawPanel);

       //set visibility
       this.setVisible(false);
   }




    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(withdrawButton)){
            BS = new BankService();
            boolean success = BS.withdraw(custIDField.getText(), Integer.parseInt(moneyField.getText()));
            if(success) {
                JOptionPane.showMessageDialog(null, "Sikeres készpénzfelvétel!");
            }else {
                JOptionPane.showMessageDialog(null,"Sikertelen készpénzfelvétel!");
            }
            ClearFields();
        }
        if (e.getSource().equals(cancelButton)){
            this.dispose();
        }
    }

    //method for clearing fields
    public void ClearFields(){
        this.custIDField.setText("");
        this.moneyField.setText("");

    }
}
