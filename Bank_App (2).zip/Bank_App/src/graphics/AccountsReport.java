package graphics;

import data.Database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class AccountsReport extends JFrame implements ActionListener{
    /*class for accounts report menu, can get all data from database to graphical output */

    //data types
   private JPanel accountsReportPanel;
   private JButton queryButton;
   private JButton cancelButton;
   private JTextArea dataArea;
   private Database database;

    //constructor with init method
   public AccountsReport(){
        init();

   }
    //init method for initialize components
   private void init(){
        //set frame
       this.setTitle("Számlák lekérdezése");
       this.setSize(800,600);
       this.setLocationRelativeTo(null);
       this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

       //initialize datatypes and components
       this.accountsReportPanel = new JPanel();
       this.accountsReportPanel.setLayout(null);
       this.accountsReportPanel.setBackground(Color.gray);

       this.queryButton = new JButton("Lekérdezés");
       this.cancelButton = new JButton("Mégse");
       this.dataArea = new JTextArea();

       //set positions and sizes of components
       this.queryButton.setBounds(10,30,150,50);
       this.cancelButton.setBounds(230,30,150,50);
       this.dataArea.setBounds(10,130,600,500);

       //add actionlistener to buttons
       this.queryButton.addActionListener(this);
       this.cancelButton.addActionListener(this);


       //add components to panel
       this.accountsReportPanel.add(queryButton);
       this.accountsReportPanel.add(cancelButton);
       this.accountsReportPanel.add(dataArea);
       this.add(accountsReportPanel);

       //set visibility
       this.setVisible(false);
   }


    @Override
    public void actionPerformed(ActionEvent e) {

       if (e.getSource().equals(cancelButton)){
           this.dispose();
       }
       if (e.getSource().equals(queryButton)){
           ArrayList<String> newList = database.readConnection();
           int i = 0;
           for (;i < newList.size()-1; i++) {
               dataArea.append(newList.get(i) + " - ");
           }
           dataArea.append(newList.get(i));


       }
    }


    public void setDb(Database connection) {
        this.database = connection;
    }






}
