package data;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;

public class Database {
    /*class for create database connection*/

    //declare datatypes
    private Connection conn;
    private PreparedStatement st;
    private ResultSet rs;

    private static final String URL = "jdbc:mysql://localhost:3306/bank";
    private static final String USER = "root";
    private static final String PWD = "";

    //constructor
    public Database(){
        try {
            conn = DriverManager.getConnection(URL,USER,PWD);
            System.out.println("Sikeres adatbázis kapcsolat!");
        } catch (Exception e) {
            System.out.println("Hiba az adatbázis kapcsolódás során! " + e);
        }
    }

    //reg method for open bank account
    public boolean reg(String id, String name, String accountType,String accountNumber,
                       String address, String phoneNumber, String email, int accountBalance){

        try {

            this.st = conn.prepareStatement("INSERT INTO CUSTOMERS(cust_id,name,accountType, accountNumber, address,phoneNumber,email, accountbalance)VALUES(?,?,?,?,?,?,?,?)");
            st.setString(1,id);
            st.setString(2,name);
            st.setString(3,accountType);
            st.setString(4,accountNumber);
            st.setString(5,address);
            st.setString(6,phoneNumber);
            st.setString(7,email);
            st.setInt(8,accountBalance);
            st.execute();
            JOptionPane.showMessageDialog(null,"Adatok sikeresen rögzítve!");
        } catch (Exception ex) {
            System.out.println("Hiba az adatok rögzítése során! " + ex);
            ex.printStackTrace();
        }
        return true;
    }

    //method for read data from database
    public ArrayList<String> readConnection(){
        ArrayList<String>lista = new ArrayList<>();
        try {
            System.out.println("A lekérdezés elkezdődött!");

            this.st = conn.prepareStatement("SELECT * FROM CUSTOMERS");
            rs = st.executeQuery();
            while (rs.next()) {
               String custid =  rs.getString("cust_id");
               lista.add(custid);
               System.out.println(custid + " id");
                String name =  rs.getString("name");
                lista.add(name);
                System.out.println(name + " name");
                String accountType =  rs.getString("accountType");
                lista.add(accountType);
                System.out.println(accountType + " accountType");
            }
        } catch (Exception e) {
            System.out.println("Hiba az adatok kiolvasása során!");
            e.printStackTrace();
        }
        System.out.println(lista);
        return lista;

    }

    //deposit method for database
    public boolean deposit(String cust_id, int depositMoney){
        boolean success = false;
        String selectSql = "SELECT * FROM customers WHERE cust_id = ?";
        String updateSql = "UPDATE customers SET accountbalance = ? WHERE cust_id = ?";
        try {
            st = conn.prepareStatement(selectSql);
            st.setString(1, cust_id);
            ResultSet rs = st.executeQuery();
            while (rs.next()){
                int currentAccountBalance =  rs.getInt("accountbalance");
                int newDepositAmount = currentAccountBalance + depositMoney;
                st = conn.prepareStatement(updateSql);
                st.setInt(1,newDepositAmount);
                st.setString(2,cust_id);
                st.executeUpdate();
                System.out.println("Sikeres befizetés!");
                success = true;
            }
        }catch (Exception e){
            System.out.println("Hiba a befizetés során!");
        }
        return success;
    }

    //withdraw method for database
    public boolean withdraw(String cust_id, int withdrawMoney){

        boolean success = false;
        String selectSql = "SELECT * FROM customers WHERE cust_id = ?";
        String updateSql = "UPDATE customers SET accountbalance = ? WHERE cust_id = ?";

        try {

            st = conn.prepareStatement(selectSql);
            st.setString(1, cust_id);
            ResultSet rs = st.executeQuery();
            while (rs.next()){

                int currentAccountBalance =  rs.getInt("accountbalance");
                int newWithdrawAmount = currentAccountBalance - withdrawMoney;
                if(newWithdrawAmount > 0) {
                    st = conn.prepareStatement(updateSql);
                    st.setInt(1, newWithdrawAmount);
                    st.setString(2, cust_id);
                    st.executeUpdate();
                    System.out.println("Sikeres pénzkivétel!");
                    success = true;
                }else {
                    System.out.println("Nincs elegendő összeg a számlán!");
                }
            }

        }catch (Exception e){
            System.out.println("Hiba a befizetés során!");

        }

        return success;

    }

    //transfer method for database
    public boolean transfer(String sourceCustId, String targetCustId, int transferAmount){

        boolean success= false;

        success = withdraw(sourceCustId,transferAmount);
        if (success) {
            success = deposit(targetCustId, transferAmount);
        }

        return  success;
    }



    //method for closing database connection
    public void CloseDatabase(){
        try {
            this.conn.close();
        }catch (Exception ex){
            System.out.println("Hiba a kapcsolat bezárásnál! " + ex);
            ex.printStackTrace();
        }

    }



}
