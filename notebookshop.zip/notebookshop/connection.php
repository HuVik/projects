<?php

    //KONSTANS VÁLTOZÓK FELVÉTELE ADATBÁZIS KAPCSOLÓDÁSHOZ
    define("host", "localhost");
    define("user", "root");
    define("pwd", "");
    define("dbname", "webshop");