<?php  require "header.php";   ?>

<div id="top">
    <img src="" id="logo" alt="" title="" />
    <?php require "menu.php";   ?>
</div>

<div id="left">
    <?php   require "kategoria.php";   ?>
</div>

<div id="right">
    <h1>Kapcsolat</h1>

    <p> <strong>Cím: </strong> 1094 Budapest, Tűzoltó u. 59. </p>
    <p> <strong>Telefonszám: </strong> 06 30 123 4567 </p>
    <p> <strong>E-mail cím: </strong> notebookshop@notebookshop.hu </p>
    <p> <strong>Nyitvatartás </strong> H-V 8:00-20:00 </p>

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2696.484324697074!2d19.077321215626114!3d47.480477579176494!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741dcfb0bb51411%3A0xad3da0ef0d607b63!2zQnVkYXBlc3QsIFTFsXpvbHTDsyB1LiA1OSwgMTA5NA!5e0!3m2!1shu!2shu!4v1604739366693!5m2!1shu!2shu" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>

</body>
</html>