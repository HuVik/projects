$(function(){

    var user = $("#user");
    var pwd = $("#pwd");
    var btn = $("#btn");


    $(btn).on("click", function(e){

        if(user.val()=="" && pwd.val()==""){

            $(user).css("border", "1px solid red");
            $(pwd).css("border", "1px solid red");
            e.preventDefault();
        }
        else if(user.val()==""){

            $(user).css("border", "1px solid red");
            $(pwd).css("border", "1px solid green");
            e.preventDefault();
        }

        else if(pwd.val()==""){

            $(user).css("border", "1px solid green");
            $(pwd).css("border", "1px solid red");
            e.preventDefault();
        }
        else{

            $(user).css("border", "1px solid green");
            $(pwd).css("border", "1px solid green");
        }
    })


    $("#auto1").click(function(){

        $("#auto1_text").toggle(300);
    })

    $("#auto2").click(function(){

        $("#auto2_text").toggle(300);
    })

    $("#auto3").click(function(){

        $("#auto3_text").toggle(300);
    })


    $(window).scroll(function(){

        var navbar = $("#navbar");

        $(navbar).toggleClass("scrolled", $(this).scrollTop()> 100);
    })

})